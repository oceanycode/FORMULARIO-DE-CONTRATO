'use strict';
contratoApp.controller('appController', [
    '$scope', '$rootScope', '$state',
    function ($scope, $rootScope, $state) {
        angular.element(document).ready(function () {
            console.log("entrando al contolador de app");
            $state.go('app.menu');
        });
    }]);
