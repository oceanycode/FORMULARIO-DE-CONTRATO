'use strict';

contratoApp.directive('semanticUiDropdown', function () {
    return {
        scope: {
            items: '=',
            selected : '='
        },
        restrict: 'E',
        link: function (scope, element, attrs) {
            let options = '';
            angular.forEach(scope.items, function (item) {
                options += '<option value="' + item.id + '">' + item.name + '</option>';
            });
            let template = '<select class="ui fluid search dropdown">' +
                '<option value="">' + attrs.placeholder + '</option>' +
                options +
                '</select>';
            $(element).html(template);
            $(element).find(".ui.fluid.search.dropdown").dropdown({
                onChange : function (value, text, choice){
                    scope.$apply(() => {
                        scope.selected=text;
                    });

                }
            });

            scope.$watch("items", function (newValue, oldValue) {
                let options = '';
                angular.forEach(scope.items, function (item) {
                    options += '<option value="' + item.id + '">' + item.name + '</option>';
                });
                let template = '<select class="ui fluid search dropdown">' +
                    '<option value="">' + attrs.placeholder + '</option>' +
                    options +
                    '</select>';
                $(element).html(template);
                $(element).find(".ui.fluid.search.dropdown").dropdown({
                    onChange : function (value, text, choice){
                        scope.$apply(() => {
                            scope.selected=text;
                        });
                    }
                });
            });
        }
    }
});

contratoApp.directive("passwordVerify", function () {
    return {
        require: "ngModel",
        scope: {
            passwordVerify: '='
        },
        link: function (scope, element, attrs, ctrl) {
            scope.$watch(function () {
                var combined;

                if (scope.passwordVerify || ctrl.$viewValue) {
                    combined = scope.passwordVerify + '_' + ctrl.$viewValue;
                }
                return combined;
            }, function (value) {
                if (value) {
                    ctrl.$parsers.unshift(function (viewValue) {
                        var origin = scope.passwordVerify;
                        if (origin !== viewValue) {
                            ctrl.$setValidity("passwordVerify", false);
                            return undefined;
                        } else {
                            ctrl.$setValidity("passwordVerify", true);
                            return viewValue;
                        }
                    });
                }
            });
        }
    };
});