'use strict';
var contratoApp = angular.module('contratosApp', [
    'ngSanitize',
    'ui.router'

]);

contratoApp.config(['$stateProvider', '$urlRouterProvider',
    function ($stateProvider, $urlRouterProvider) {
        $urlRouterProvider.otherwise('/menu');
        $stateProvider
            .state('menu', {
                url: '/menu',
                templateUrl: 'view/template/menu.html',
                controller: 'menuController'
            })
            .state('arrendamiento', {
                url: '/arrendamiento',
                templateUrl: 'view/contratos/arrendamiento.html',
                controller: 'arrendamientoController',
                controllerAs: 'arrendamiento'
            })
            .state('compraventa', {
                url: '/compraventa',
                templateUrl: 'view/contratos/compraventa.html',
                controller: 'compraventaController',
                controllerAs: 'compraventa'
            })
            .state('poderCorto', {
                url: '/poder-corto',
                templateUrl: 'view/contratos/poder-corto.html',
                controller: 'poderCortoController',
                controllerAs: 'poderCorto'
            })
            .state('poderLargo', {
                url: '/poder-largo',
                templateUrl: 'view/contratos/poder-largo.html',
                controller: 'poderLargoController',
                controllerAs: 'poderLargo'
            })
            .state('especialComprador', {
                url: '/especial-comprador',
                templateUrl: 'view/contratos/poder-especial-comprador.html',
                controller: 'especialCompradorController',
                controllerAs: 'especialComprador'
            })
            .state('especialVendedor', {
                url: '/especial-vendedor',
                templateUrl: 'view/contratos/poder-especial-vendedor.html',
                controller: 'especialVendedorController',
                controllerAs: 'especialVendedor'
            })
    }]);

contratoApp.run(['$rootScope', '$state', '$templateCache', '$http', function ($rootScope, $state, $templateCache, $http) {
    $rootScope.$state = $state;
    //$rootScope.setting = setting;
    //Este manejador de evento se coloco para eliminar todos los tooltips que
    //quedaron activos al validar un formulario debido a que la plantilla no
    //tiene este comportamiento por defecto.
    $rootScope.$on('$stateChangeStart',
        function (event, toState, toParams, fromState, fromParams, options) {

            console.log("Detectado cambio de estado de la navegacion");
            console.log(toState.name);
            //$state.go(toState.name);
        });
    //$rootScope.$on('$stateChangeSuccess', function (event, toState, toParams, fromState, fromParams, options){
    //})
    // $rootScope.$on('$viewContentLoaded', function () {
    //     $templateCache.removeAll();
    // });
    //$http.defaults.headers.common.Authorization = 'Bearer e175fd5e-f328-424d-b54c-324a7b253d47';
}]);
