'use strict';
contratoApp.service('appService', ['$http',
    function ($http) {
        /**
         * Funciion que obtiene el listado de ciudades
         * @returns {*}
         */
        this.getCiudades = function (data) {
            return $http({
                method: 'POST',
                url: 'resources/ciudades.json',
            })
        };

        this.getBancos = function (data) {
            return $http({
                method: 'POST',
                url: 'resources/bancos.json',
            })
        };

        /**
         * Funcion que obtiene un documento
         * en formato Word
         * @param data
         * @returns {*}
         */
        this.getDocumentWord = function (data) {
            data.action = 'download-word';
            return $http({
                method: 'POST',
                data : data,
                url: 'php/core.php'
            })
        };

        /**
         * Funcion que obtiene un documento pdf
         * @param data
         * @returns {*}
         */
        this.getDocumentPDF = function (data) {
            data.action = 'download-pdf';
            return $http({
                method: 'POST',
                data : data,
                url: 'php/core.php',
                responseType: 'arraybuffer'
            })
        };

        /**
         * Funcion que consume el servicio de envio de email
         * a un correo electornico
         * @param data
         * @returns {*}
         */
        this.sendEmail = function (data) {
            data.action = 'send-email';
            return $http({
                method: 'POST',
                data : data,
                url: 'php/core.php'
            })
        };
    }]);
