'use strict';
contratoApp.controller('menuController', [
    '$scope', '$rootScope', '$state',
    function ($scope, $rootScope, $state) {
        angular.element(document).ready(function () {
            console.log("entrando al menu");
        });
    }]);
