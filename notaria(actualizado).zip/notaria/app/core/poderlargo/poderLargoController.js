'use strict';
contratoApp.controller('poderLargoController', ['$scope', '$http', 'appService',
    function ($scope, $http, $appService) {
        $scope.ciudades = [];
        $scope.pagina = 1;
        $scope.siguiente = function () {
            $scope.pagina++;
        };
        $scope.anterior = function () {
            $scope.pagina--;
        };
        $scope.user = {
            authorized : false,
            email : '',
            emailValidate : ''
        };
        $scope.answers = {
        };

        $scope.enableSendMail = function(){
            var validation = $scope.user.authorized;
            if (($scope.user.email!=='' && $scope.user.emailValidate!=='') && ($scope.user.email===$scope.user.emailValidate)){
                validation = validation && true;
            }else {
                validation = validation && false;
            }
            console.log('validacion', validation);
            return validation;
        };

        $scope.validate = function () {
            if ($scope.answers.fav === false) {
                alert('You\'ve not checked \'em all!')
            }
            else {
                alert('You\'ve checked \'em all!')
            }
        };

        $scope.generateTextNumber = function (value, atributename) {
            var n = value;
            var o = ["DIEZ", "ONCE", "DOCE", "TRECE", "CATORCE", "QUINCE", "DIECISÉIS", "DIECISIETE", "DIECIOCHO", "DIECINUEVE", "VEINTE", "VEINTIUNO", "VEINTIDÓS", "VEINTITRÉS", "VEINTICUATRO", "VEINTICINCO", "VEINTISÉIS", "VEINTISIETE", "VEINTIOCHO", "VEINTINUEVE"];
            var u = ["CERO", "UNO", "DOS", "TRES", "CUATRO", "CINCO", "SEIS", "SIETE", "OCHO", "NUEVE"];
            var d = ["", "", "", "TREINTA", "CUARENTA", "CINCUENTA", "SESENTA", "SETENTA", "OCHENTA", "NOVENTA"];
            var c = ["", "CIEN", "DOSCIENTOS", "TRESCIENTOS", "CUATROCIENTOS", "QUINIENTOS", "SEISCIENTOS", "SETECIENTOS", "OCHOCIENTOS", "NOVECIENTOS"];
            n = n.replace(/\./g, '');
            n = parseFloat(n).toFixed(2);
            /*se limita a dos decimales, no sabía que existía toFixed() :)*/
            var p = n.toString().substring(n.toString().indexOf(".") + 1);
            /*decimales*/
            var m = n.toString().substring(0, n.toString().indexOf("."));
            /*número sin decimales*/
            m = parseFloat(m).toString().split("").reverse();
            /*tampoco que reverse() existía :D*/
            var t = "";
            for (var i = 0; i < m.length; i += 3) {
                var x = t;
                /*formamos un número de 2 dígitos*/
                var b = m[i + 1] !== undefined ? parseFloat(m[i + 1].toString() + m[i].toString()) : parseFloat(m[i].toString());
                /*analizamos el 3 dígito*/
                t = m[i + 2] !== undefined ? (c[m[i + 2]] + " ") : "";
                t += b < 10 ? u[b] : (b < 30 ? o[b - 10] : (d[m[i + 1]] + (m[i] == '0' ? "" : (" Y " + u[m[i]]))));
                t = t === "CIENTO CERO" ? "CIEN" : t;
                if (2 < i && i < 6)
                    t = t === "UNO" ? "MIL " : (t.replace("UNO", "UN") + " MIL ");
                if (5 < i && i < 9)
                    t = t === "UNO" ? "UN MILLÓN " : (t.replace("UNO", "UN") + " MILLONES ");
                if (8 < i && i < 15)
                    t = t === "UNO" ? "MIL MILLÓNES " : (t.replace("UNO", "UN") + " MIL MILLÓNES  ");
                t += x;
                //t=i<3?t:(i<6?((t=="uno"?"mil ":(t+" mil "))+x):((t=="uno"?"un millón ":(t+" millones "))+x));
            }
            /*y agregamos los decimales*/
            t += " PESOS";
            /*correcciones: siempre son necesarias*/
            t = t.replace("  ", " ");
            t = t.replace("CERO", "");
            t = t.replace("CERO", "", "");
            t = t.replace("MIL   PESOS", "", "", "");
            t = t.replace("MIL MILLÓNES  CERO", "", "", "");
            t = t.replace("MILLÓNES   MILLONES", "MILLÓNES");
            t = t.replace("MILLÓNES  MILLONES", "MILLÓNES");
            t = t.replace("MILLONES  CERO", "", "", "");
            t = t.replace("MILLÓNES  CERO", "MILLÓNES");
            t = t.replace("MIL  CERO PESOS", "", "", "");
            t = t.replace("CIENTO Y", "CIEN Y");
            t = t.replace("CIEN DIEZ", "CIENTO DIEZ");
            t = t.replace("CIEN ONCE", "CIENTO ONCE");
            t = t.replace("CIEN DOCE", "CIENTO DOCE");
            t = t.replace("CIEN TRECE", "CIENTO TRECE");
            t = t.replace("CIEN CATORCE", "CIENTO CATORCE");
            t = t.replace("CIEN QUINCE", "CIENTO QUINCE");
            t = t.replace("CIEN DIECISÉIS", "CIENTO DIECISÉIS");
            t = t.replace("CIEN DIECISIETE", "CIENTO DIECISIETE");
            t = t.replace("CIEN DIECIOCHO", "CIENTO DIECIOCHO");
            t = t.replace("CIEN DIECINUEVE", "CIENTO DIECINUEVE");
            t = t.replace("CIEN VEINTE", "CIENTO VEINTE");
            t = t.replace("CIEN VEINTIUN", "CIENTO VEINTIUN");
            t = t.replace("CIEN VEINTIUNO", "CIENTO VEINTIUNO");
            t = t.replace("CIEN VEINTIDÓS", "CIENTO VEINTIDÓS");
            t = t.replace("CIEN VEINTITRÉS", "CIENTO VEINTITRÉS");
            t = t.replace("CIEN VEINTICUATRO", "CIENTO VEINTICUATRO");
            t = t.replace("CIEN VEINTICINCO", "CIENTO VEINTICINCO");
            t = t.replace("CIEN VEINTISÉIS", "CIENTO VEINTISÉIS");
            t = t.replace("CIEN VEINTISIETE", "CIENTO VEINTISIETE");
            t = t.replace("CIEN VEINTIOCHO", "CIENTO VEINTIOCHO");
            t = t.replace("CIEN VEINTINUEVE", "CIENTO VEINTINUEVE");
            t = t.replace("CIEN TREINTA", "CIENTO TREINTA");
            t = t.replace("CIEN TREINTA Y UNO", "CIENTO TREINTA Y UNO");
            t = t.replace("CIEN TREINTA Y DOS", "CIENTO TREINTA Y DOS");
            t = t.replace("CIEN TREINTA Y TRES", "CIENTO TREINTA Y TRES");
            t = t.replace("CIEN TREINTA Y CUATRO", "CIENTO TREINTA Y CUATRO");
            t = t.replace("CIEN TREINTA Y CINCO", "CIENTO TREINTA Y CINCO");
            t = t.replace("CIEN TREINTA Y SEIS", "CIENTO TREINTA Y SEIS");
            t = t.replace("CIEN TREINTA Y SIETE", "CIENTO TREINTA Y SIETE");
            t = t.replace("CIEN TREINTA Y OCHO", "CIENTO TREINTA Y OCHO");
            t = t.replace("CIEN TREINTA Y NUEVE", "CIENTO TREINTA Y NUEVE");
            t = t.replace("CIEN CUARENTA", "CIENTO CUARENTA");
            t = t.replace("CIEN CUARENTA Y UNO", "CIENTO CUARENTA Y UNO");
            t = t.replace("CIEN CUARENTA Y DOS", "CIENTO CUARENTA Y DOS");
            t = t.replace("CIEN CUARENTA Y TRES", "CIENTO CUARENTA Y TRES");
            t = t.replace("CIEN CUARENTA Y CUATRO", "CIENTO CUARENTA Y CUATRO");
            t = t.replace("CIEN CUARENTA Y CINCO", "CIENTO CUARENTA Y CINCO");
            t = t.replace("CIEN CUARENTA Y SEIS", "CIENTO CUARENTA Y SEIS");
            t = t.replace("CIEN CUARENTA Y SIETE", "CIENTO CUARENTA Y SIETE");
            t = t.replace("CIEN CUARENTA Y OCHO", "CIENTO CUARENTA Y OCHO");
            t = t.replace("CIEN CUARENTA Y NUEVE", "CIENTO CUARENTA Y NUEVE");
            t = t.replace("CIEN CINCUENTA", "CIENTO CINCUENTA");
            t = t.replace("CIEN CINCUENTA Y UNO", "CIENTO CINCUENTA Y UNO");
            t = t.replace("CIEN CINCUENTA Y DOS", "CIENTO CINCUENTA Y DOS");
            t = t.replace("CIEN CINCUENTA Y TRES", "CIENTO CINCUENTA Y TRES");
            t = t.replace("CIEN CINCUENTA Y CUATRO", "CIENTO CINCUENTA Y CUATRO");
            t = t.replace("CIEN CINCUENTA Y CINCO", "CIENTO CINCUENTA Y CINCO");
            t = t.replace("CIEN CINCUENTA Y SEIS", "CIENTO CINCUENTA Y SEIS");
            t = t.replace("CIEN CINCUENTA Y SIETE", "CIENTO CINCUENTA Y SIETE");
            t = t.replace("CIEN CINCUENTA Y OCHO", "CIENTO CINCUENTA Y OCHO");
            t = t.replace("CIEN CINCUENTA Y NUEVE", "CIENTO CINCUENTA Y NUEVE");
            t = t.replace("CIEN SESENTA", "CIENTO SESENTA");
            t = t.replace("CIEN SESENTA Y UNO", "CIENTO SESENTA Y UNO");
            t = t.replace("CIEN SESENTA Y DOS", "CIENTO SESENTA Y DOS");
            t = t.replace("CIEN SESENTA Y TRES", "CIENTO SESENTA Y TRES");
            t = t.replace("CIEN SESENTA Y CUATRO", "CIENTO SESENTA Y CUATRO");
            t = t.replace("CIEN SESENTA Y CINCO", "CIENTO SESENTA Y CINCO");
            t = t.replace("CIEN SESENTA Y SEIS", "CIENTO SESENTA Y SEIS");
            t = t.replace("CIEN SESENTA Y SIETE", "CIENTO SESENTA Y SIETE");
            t = t.replace("CIEN SESENTA Y OCHO", "CIENTO SESENTA Y OCHO");
            t = t.replace("CIEN SESENTA Y NUEVE", "CIENTO SESENTA Y NUEVE");
            t = t.replace("CIEN SETENTA", "CIENTO SETENTA");
            t = t.replace("CIEN SETENTA Y UNO", "CIENTO SETENTA Y UNO");
            t = t.replace("CIEN SETENTA Y DOS", "CIENTO SETENTA Y DOS");
            t = t.replace("CIEN SETENTA Y TRES", "CIENTO SETENTA Y TRES");
            t = t.replace("CIEN SETENTA Y CUATRO", "CIENTO SETENTA Y CUATRO");
            t = t.replace("CIEN SETENTA Y CINCO", "CIENTO SETENTA Y CINCO");
            t = t.replace("CIEN SETENTA Y SEIS", "CIENTO SETENTA Y SEIS");
            t = t.replace("CIEN SETENTA Y SIETE", "CIENTO SETENTA Y SIETE");
            t = t.replace("CIEN SETENTA Y OCHO", "CIENTO SETENTA Y OCHO");
            t = t.replace("CIEN SETENTA Y NUEVE", "CIENTO SETENTA Y NUEVE");
            t = t.replace("CIEN OCHENTA", "CIENTO OCHENTA");
            t = t.replace("CIEN OCHENTA Y UNO", "CIENTO OCHENTA Y UNO");
            t = t.replace("CIEN OCHENTA Y DOS", "CIENTO OCHENTA Y DOS");
            t = t.replace("CIEN OCHENTA Y TRES", "CIENTO OCHENTA Y TRES");
            t = t.replace("CIEN OCHENTA Y CUATRO", "CIENTO OCHENTA Y CUATRO");
            t = t.replace("CIEN OCHENTA Y CINCO", "CIENTO OCHENTA Y CINCO");
            t = t.replace("CIEN OCHENTA Y SEIS", "CIENTO OCHENTA Y SEIS");
            t = t.replace("CIEN OCHENTA Y SIETE", "CIENTO OCHENTA Y SIETE");
            t = t.replace("CIEN OCHENTA Y OCHO", "CIENTO OCHENTA Y OCHO");
            t = t.replace("CIEN OCHENTA Y NUEVE", "CIENTO OCHENTA Y NUEVE");
            t = t.replace("CIEN NOVENTA", "CIENTO NOVENTA");
            t = t.replace("CIEN NOVENTA Y UNO", "CIENTO NOVENTA Y UNO");
            t = t.replace("CIEN NOVENTA Y DOS", "CIENTO NOVENTA Y DOS");
            t = t.replace("CIEN NOVENTA Y TRES", "CIENTO NOVENTA Y TRES");
            t = t.replace("CIEN NOVENTA Y CUATRO", "CIENTO NOVENTA Y CUATRO");
            t = t.replace("CIEN NOVENTA Y CINCO", "CIENTO NOVENTA Y CINCO");
            t = t.replace("CIEN NOVENTA Y SEIS", "CIENTO NOVENTA Y SEIS");
            t = t.replace("CIEN NOVENTA Y SIETE", "CIENTO NOVENTA Y SIETE");
            t = t.replace("CIEN NOVENTA Y OCHO", "CIENTO NOVENTA Y OCHO");
            t = t.replace("CIEN NOVENTA Y NUEVE", "CIENTO NOVENTA Y NUEVE");
            t = t.replace("PESOS", "");
            t = t.replace("undefined undefined y undefined", "");
            //alert("Numero: "+n+"\nNº Dígitos: "+m.length+"\nDígitos: "+m+"\nDecimales: "+p+"\nt: "+t);
            $scope[atributename]=t;
        };

        $scope.downloadDocumentPDF = function(){
            console.log('realizando la descarga del documento pdf');
            var data = {
                html : $('#contract-document').html().replace(/\n/g,'').replace(/<\!--.*?-->/g, "")
            };
            function download(filename, text) {
                // var byteNumbers = new Uint8Array(text.length);
                // for (var i = 0; i < text.length; i++) {
                //     byteNumbers[i] = text.charCodeAt(i);
                // }
                var blob = new Blob([text], {type: 'application/pdf;charset=UTF-8'});
                // Construct the uri
                var uri = URL.createObjectURL(blob);
                // Construct the <a> element
                var link = document.createElement("a");
                link.download = filename;
                link.href = uri;
                document.body.appendChild(link);
                link.click();
                // Cleanup the DOM
                document.body.removeChild(link);
            };
            $appService.getDocumentPDF(data)
                .success(function(response){
                    var data = response;
                    if(data){
                        download("contrato.pdf", data);
                    }
                })
                .error(function(error){
                    console.log(error)
                });
        };

        $scope.downloadDocumentWord = function(){
            console.log('realizando la descarga del documento word');
            var data = {
                html : $('#contract-document').html().replace(/\n/g,'').replace(/<\!--.*?-->/g, "")
            };
            console.log(data);
            function download(filename, text) {
                // var byteNumbers = new Uint8Array(text.length);
                // for (var i = 0; i < text.length; i++) {
                //     byteNumbers[i] = text.charCodeAt(i);
                // }
                var blob = new Blob([text], {type: "text/plain;charset=UTF-8"});
                // Construct the uri
                var uri = URL.createObjectURL(blob);
                // Construct the <a> element
                var link = document.createElement("a");
                link.download = filename;
                link.href = uri;
                document.body.appendChild(link);
                link.click();
                // Cleanup the DOM
                document.body.removeChild(link);
            };
            //console.log(JSON.stringify(data));
            $appService.getDocumentWord(data)
                .success(function(response){
                    var data = response;
                    if(data){
                        download("contrato.doc", data);
                    }
                })
                .error(function(error){
                    console.log(error)
                });
        };

        $scope.testEmail = function(){
            console.log('realizando prueba de envio de correo');
            var data = {
                html : $('#contract-document').html().replace(/\n/g,'').replace(/<\!--.*?-->/g, ""),
                email : $scope.user.email
            };
            $appService.sendEmail(data)
                .success(function(response){
                    var data = response;
                    if(data){
                        window.location.href = "http://www.notaria19bogota.com/proceso-exitoso";
                        console.log(data);
                    }
                })
                .error(function(error){
                    window.location.href = "http://www.notaria19bogota.com/proceso-exitoso";
                    console.log(error)
                });
        };


        angular.element(document).ready(function () {
            console.log("controlador de compraventa cargado");

            $('input.number').keyup(function (event) {
                // skip for arrow keys
                if (event.which >= 37 && event.which <= 40) {
                    event.preventDefault();
                }

                $(this).val(function (index, value) {
                    return value
                        .replace(/\D/g, "")
                        .replace(/\B(?=(\d{3})+(?!\d)\.?)/g, ".")
                        ;
                });
            });
            $appService.getCiudades()
                .success(function (response){
                    console.log('resuesta');
                    console.log(response);
                    $scope.ciudades = response;
                }).error(function (error){
                    console.log('error');
                    console.log(error);
                });
        });
    }]);