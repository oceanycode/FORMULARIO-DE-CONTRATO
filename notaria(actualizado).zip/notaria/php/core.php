<?php

require_once('./lib/PHPMailer/PHPMailerAutoload.php');
require_once("./lib/html2pdf/html2pdf.class.php");
require_once("./lib/html2doc/html_to_doc.php");

validateAction();

function validateAction(){
    $postdata = file_get_contents("php://input");
    $request = json_decode($postdata);

    $action = $request->action;
    switch($action)
    {
        case 'download-pdf':{
            echo generatePdf($request);
            break;
        }
        case 'download-word':{
            echo generateDoc($request);
            break;
        }
        case 'send-email':{
            sendEmail($request);
            break;
        }
        default :
            echo "{'response' : 500 'error' : 'accion invalida'}";
    }
}

function generatePdf($request){
    try
    {
        $content = $request->html;
        $html2pdf = new HTML2PDF('P', 'A4', 'es',true,'UTF-8',30);
        $html2pdf->setDefaultFont('Arial');
        //$html2pdf->writeHTML(utf8_encode($content));
        $html2pdf->writeHTML($content);
        return  $html2pdf->Output('contrato.pdf','S');

    }
    catch(HTML2PDF_exception $e) {
        echo $e;
        exit;
    }
}

function generateDoc($request){
    $content = $request->html;
    $htmltodoc= new HTML_TO_DOC();
    return $htmltodoc->createDoc($content, "contrato.doc", false,'S');
}

function sendEmail($request){
    $email =  $request->email;
    $mail = new PHPMailer();
    $mail->IsSMTP();
    $mail->Host = 'mail.notaria19bogota.com';
    $mail->SMTPAuth = true;
    $mail->SMTPSecure = 'tls';
    $mail->Username = 'contratosonline@notaria19bogota.com';
    $mail->Password = '{MKnO3rL@rg0';
    $mail->Port = 587;

    $mail->Username = 'contratosonline@notaria19bogota.com';
    $mail->FromName   = "Contratos Online Notaria 19 Bogota";
    $mail->From = 'contratosonline@notaria19bogota.com';

    $mail->AddAddress($email);
    $mail->AddAddress('contratosenlinea@notaria19bogota.com');

    $mail->Subject = "Su Contrato esta listo";
    $mail->Body = "Contrato online generado con exito";

    $mail->AddStringAttachment(generatePdf($request), 'contrato.pdf', 'base64', 'application/pdf');
    $mail->AddStringAttachment(generateDoc($request), 'contrato.doc');
    if ($mail->Send())
        echo "{'response':200}";
    else{
        echo "{'response' : 500}" . $mail->ErrorInfo;
    }
}

