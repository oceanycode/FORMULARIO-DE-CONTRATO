<?php
/**
 * Created by IntelliJ IDEA.
 * User: Hamer
 * Date: 22/11/2017
 * Time: 19:06
 */
include("../html_to_doc.php");
$content = "
    <style>
        .title{
            font-size: 14pt;
            text-align: center;
        }
        
    </style>
     
                        <p class=\"title\"><strong>PROMESA DE COMPRAVENTA CELEBRADA ENTRE<br>

                        <!-- ngIf: answers.tipo.comprador==='natural' --><span class=\"mark ng-binding ng-scope\" ng-if=\"answers.tipo.comprador==='natural'\">Brayan Hamer Rodriguez Sanchez</span><!-- end ngIf: answers.tipo.comprador==='natural' -->
                        <!-- ngIf: answers.tipo.comprador==='juridico' -->
                        <!-- ngIf: answers.tipo.comprador2==='natural' -->
                        <!-- ngIf: answers.tipo.comprador2=== 'juridico' -->
                        <!-- ngIf: answers.tipo.comprador3=== 'natural' -->
                        <!-- ngIf: answers.tipo.comprador3=== 'juridico' -->
                        <!-- ngIf: answers.tipo.comprador4=== 'natural' -->
                        <!-- ngIf: answers.tipo.comprador4=== 'juridico' -->
                        Y
                        <!-- ngIf: answers.tipo.vendedor=== 'natural' --><span class=\"mark ng-binding ng-scope\" ng-if=\"answers.tipo.vendedor=== 'natural'\">JOHSN</span><!-- end ngIf: answers.tipo.vendedor=== 'natural' -->
                        <!-- ngIf: answers.tipo.vendedor=== 'juridico' -->
                        <!-- ngIf: answers.tipo.vendedor2=== 'natural' -->
                        <!-- ngIf: answers.tipo.vendedor2=== 'juridico' -->
                        <!-- ngIf: answers.tipo.vendedor3=== 'natural' -->
                        <!-- ngIf: answers.tipo.vendedor3=== 'juridico' -->
                        <!-- ngIf: answers.tipo.vendedor4=== 'natural' -->
                        <!-- ngIf: answers.tipo.vendedor4=== 'juridico' -->
                    </strong></p>
                    <!--tipo vendedor-->
                    <p><!-- ngIf: answers.tipo.vendedor=== 'juridico' --></p>

                    <p><strong>CL�USULA PRIMERA:</strong>
                        <span class=\"mark ng-binding\">EL PROMITENTE VENDEDOR</span>
                        <!-- ngIf: answers.denominacion.vendedor=== 'EL PROMITENTE VENDEDOR' || answers.denominacion.vendedor=== 'LA PROMITENTE VENDEDORA' --><span class=\"mark ng-scope\" ng-if=\"answers.denominacion.vendedor=== 'EL PROMITENTE VENDEDOR' || answers.denominacion.vendedor=== 'LA PROMITENTE VENDEDORA'\">
                            promete
                        </span><!-- end ngIf: answers.denominacion.vendedor=== 'EL PROMITENTE VENDEDOR' || answers.denominacion.vendedor=== 'LA PROMITENTE VENDEDORA' -->
                        <!-- ngIf: answers.denominacion.vendedor=== 'LAS PROMITENTES VENDEDORAS' || answers.denominacion.vendedor=== 'LOS PROMITENTES VENDEDORES' -->
                        vender a
                        <span class=\"mark ng-binding\">EL PROMITENTE COMPRADOR</span>
                        y
                        <!-- ngIf: answers.denominacion.comprador=== 'EL PROMITENTE COMPRADOR' --><span class=\"mark ng-scope\" ng-if=\"answers.denominacion.comprador=== 'EL PROMITENTE COMPRADOR'\">�ste</span><!-- end ngIf: answers.denominacion.comprador=== 'EL PROMITENTE COMPRADOR' -->
                        <!-- ngIf: answers.denominacion.comprador=== 'LA PROMITENTE COMPRADORA' -->
                        <!-- ngIf: answers.denominacion.comprador=== 'LAS PROMITENTES COMPRADORAS' -->
                        <!-- ngIf: answers.denominacion.comprador=== 'LOS PROMITENTES COMPRADORES' -->
                        se compromete a comprarle, el derecho
                        <!-- ngIf: answers.derechocuotavendedor==='no' -->
                        <!-- ngIf: answers.derechocuotavendedor==='si' --><span class=\"mark ng-binding ng-scope\" ng-if=\"answers.derechocuotavendedor==='si'\">de cuota de dominio del
                            45%
                        </span><!-- end ngIf: answers.derechocuotavendedor==='si' -->
                        y posesi�n efectiva que
                        <span class=\"mark ng-binding\">EL PROMITENTE VENDEDOR</span>
                        tiene y ejerce sobre
                        <!-- ngIf: answers.variosinmuebles=== 'no' -->
                        <!-- ngIf: answers.variosinmuebles=== 'si' --><span class=\"mark ng-scope\" ng-if=\"answers.variosinmuebles=== 'si'\">los siguientes inmuebles de su propiedad:</span><!-- end ngIf: answers.variosinmuebles=== 'si' -->
                        <span class=\"mark ng-binding\">Oficina</span>
                        <span class=\"mark ng-binding\">ubicado en calle 3 sur # 12-02</span>
                        <!-- ngIf: answers.poseedependencias==='si' --><span class=\"mark ng-binding ng-scope\" ng-if=\"answers.poseedependencias==='si'\">dos garajes</span><!-- end ngIf: answers.poseedependencias==='si' -->
                        . El cual tiene matr�cula inmobiliaria n�mero
                        <span class=\"mark ng-binding\">12342134</span>
                        <!-- ngIf: agregarinmueble_2 -->
                        <!-- ngIf: agregarinmueble_3 -->
                        <!-- ngIf: agregarinmueble_4 -->
                        ,
                        de la oficina de instrumentos p�blicos respectiva.
                        <br>
                        PAR�GRAFO. No obstante la cabida, la venta se promete como cuerpo cierto y en ella quedan
                        comprendidos los derechos, usos, costumbres y dem�s que legalmente le corresponde.
                    </p>

                    <p><strong>CL�USULA SEGUNDA: TRADICI�N DEL INMUEBLE:</strong>
                        <!-- ngIf: answers.tipo.vendedor=== 'natural' --><span ng-if=\"answers.tipo.vendedor=== 'natural' \" class=\"ng-scope\"><span class=\"mark ng-binding\">EL PROMITENTE VENDEDOR</span> adquiri� <!-- ngIf: answers.derechocuotavendedor==='si' --><span class=\"mark ng-binding ng-scope\" ng-if=\"answers.derechocuotavendedor==='si'\">el derecho de cuota del 45% sobre</span><!-- end ngIf: answers.derechocuotavendedor==='si' --> <!-- ngIf: answers.variosinmuebles=== 'si' --><span class=\"mark ng-scope\" ng-if=\"answers.variosinmuebles=== 'si'\">los inmuebles</span><!-- end ngIf: answers.variosinmuebles=== 'si' --><span class=\"mark ng-hide\" ng-hide=\"answers.variosinmuebles=== 'si'\">el inmueble</span> materia del presente contrato de PROMESA DE COMPRAVENTA con <!-- ngIf: answers.estadocivilInmueble=== 'si' --><span class=\"mark ng-binding ng-scope\" ng-if=\"answers.estadocivilInmueble=== 'si'\">su mismo estado civil actual </span><!-- end ngIf: answers.estadocivilInmueble=== 'si' --><!-- ngIf: answers.estadocivilInmueble=== 'no' --></span><!-- end ngIf: answers.tipo.vendedor=== 'natural' -->
                        <!-- ngIf: answers.tipo.vendedor2==='natural' -->,
                        <!-- ngIf: answers.tipo.vendedor=== 'juridico' -->
                        <!-- ngIf: answers.tipo.vendedor2=== 'juridico' -->
                        a trav�s de
                        <span class=\"mark ng-binding\" ng-hide=\"answers.tipocontrato==='remate' || answers.tipocontrato==='sentencia'\">
                            Compraventa
                        </span>
                        <!-- ngIf: answers.tipocontrato==='remate' -->
                        <!-- ngIf: answers.tipocontrato==='sentencia' -->
                        , el cual consta mediante escritura p�blica n�mero
                        <span class=\"mark ng-binding\">23424234</span>
                        , de
                        <span class=\"mark ng-binding\">noviembre 30, 2017</span>
                        , de la notar�a n�mero
                        <span class=\"mark ng-binding\">12</span>
                        de
                        <span class=\"mark ng-binding\"></span>
                        el cual fue registrado en el folio de matr�cula inmobiliaria correspondiente al inmueble objeto
                        de este
                        contrato en la oficina de instrumentos p�blicos respectiva.
                    </p>

                    <p><strong>CL�USULA TERCERA:</strong> El precio del inmueble que se promete en venta es de
                        ($
                        <span class=\"mark ng-binding\">1231233</span>
                        )
                        <span class=\"mark ng-binding\">
                            UN MILL?N DOSCIENTOS TREINTA Y UN MIL DOSCIENTOS TREINTA Y TRES 
                        </span>
                        (DE) PESOS MONEDA LEGAL, suma �sta que
                        <span class=\"mark ng-binding\">EL PROMITENTE COMPRADOR</span>
                        pagar� a
                        <span class=\"mark ng-binding\">EL PROMITENTE VENDEDOR</span>
                        de la siguiente forma
                        <span class=\"mark ng-binding\">abndsbcmsdbncs</span>
                        .
                    </p>

                    <p><strong>CL�USULA CUARTA:</strong>
                        <span class=\"mark ng-binding\">EL PROMITENTE COMPRADOR</span>
                        y
                        <span class=\"mark ng-binding\">EL PROMITENTE VENDEDOR</span>
                        se comprometen a firmar la ESCRITURA P�BLICA DE COMPRAVENTA el d�a:
                        <span class=\"mark ng-binding\">noviembre 16, 2017</span>
                        , a las
                        <span class=\"mark ng-binding\">11:34 PM</span>
                        , en la Notar�a
                        <span class=\"mark ng-binding\">12</span>
                        de
                        <span class=\"mark ng-binding\"></span>
                        .
                    </p>

                    <p><strong>CL�USULA QUINTA:</strong>
                        <span class=\"mark ng-binding\">EL PROMITENTE VENDEDOR</span>
                        garantiza que el inmueble objeto del presente Contrato de PROMESA DE COMPRAVENTA es de su
                        exclusiva propiedad y se encuentra libre de condiciones resolutorias, pleito pendiente, embargo
                        judicial, derechos de usufructo, uso, habitaci�n, limitaciones del dominio, censo,
                        anticresis, hipotecas, contratos de arrendamiento por escritura p�blica, afectaci�n
                        a vivienda familiar, que no se ha constituido sobre �l Patrimonio de Familia
                        Inembargable, y, en general, de todo gravamen, pero que en todo caso responder� del
                        saneamiento conforme a la ley.
                    </p>

                    <p><strong>CL�USULA SEXTA:</strong>
                        <span class=\"mark ng-binding\">EL PROMITENTE VENDEDOR</span>
                        se obliga a entregar el inmueble que promete en venta a paz y salvo por toda clase de impuestos,
                        tasas, contribuciones, servicios p�blicos a cargo del inmueble, as� como las
                        cuotas de administraci�n para con la copropiedad.
                        <span class=\"mark ng-binding\">EL PROMITENTE VENDEDOR</span>
                        Tambien garantiza(n) que no a enajenado ni prometido enajenar a ninguna persona distinta al aqui
                        <span class=\"mark ng-binding\">EL PROMITENTE COMPRADOR</span>
                        el derecho de dominio o propiedad sobre el inmueble mencionado en esta promesa de compraventa;
                        adem�s
                        garantiza(n) que tiene(n) el pleno dominio y posici�n de la propiedad material del mismo.
                    </p>

                    <p><strong>CL�USULA S�PTIMA:</strong> Los gastos que se causen por la escritura de
                        compraventa ser�n
                        cancelados as�: 1. La retenci�n en la fuente por cuenta exclusiva del
                        <span class=\"mark ng-binding\">EL PROMITENTE VENDEDOR</span>
                        ; 2. Los gastos notariales por partes iguales entre ambos contratantes; y, 3. Los gastos de
                        beneficencia y registro ser�n de cuenta exclusiva
                        <!-- ngIf: answers.denominacion.comprador=== 'EL PROMITENTE COMPRADOR' --><span class=\"mark ng-scope\" ng-if=\"answers.denominacion.comprador=== 'EL PROMITENTE COMPRADOR'\">de</span><!-- end ngIf: answers.denominacion.comprador=== 'EL PROMITENTE COMPRADOR' -->
                        <!-- ngIf: answers.denominacion.comprador=== 'LA PROMITENTE COMPRADORA' -->
                        <span class=\"mark ng-binding\">EL PROMITENTE COMPRADOR</span>
                        .
                    </p>

                    <p><!-- ngIf: answers.clausulaarras==='Arras' --><span ng-if=\"answers.clausulaarras==='Arras'\" class=\"ng-scope\"><strong>CL�USULA OCTAVA:</strong> Las partes fijan como arras del negocio la suma de ($<span class=\"mark ng-binding\">12312332</span>) <span class=\"mark ng-binding\">DOCE MILLONES TRESCIENTOS DOCE MIL TRESCIENTOS TREINTA Y DOS </span> (DE) PESOS MONEDA LEGAL, suma que perder� la parte que incumpla con una o varias de las obligaciones
                        contenidas en las cl�usulas del presente contrato de PROMESA DE COMPRAVENTA que, para su
                        cobro judicial, presta m�rito suficiente junto con la prueba del incumplimiento.</span><!-- end ngIf: answers.clausulaarras==='Arras' -->
                        <!-- ngIf: answers.clausulaarras==='Cl�sula penal' --></p><p><strong>PAR�GRAFO PRIMERO.</strong> La parte que no hubiere cumplido o se hubiere allanado a
                        cumplir sus
                        obligaciones, podr� demandar en caso de que el otro no cumpla o no se allane a cumplir las que
                        le
                        corresponden, bien el cumplimiento del contrato, o bien la resoluci�n del contrato de inmediato
                        con la
                        simple notificaci�n que le haga a la parte incumplida o mediante correo certificado o por v�a
                        ordinaria.
                        En ambos casos, conjuntamente con el cumplimiento o la resoluci�n del contrato, tendr� derecho
                        la parte
                        cumplida a pedir el pago de la pena y la indemnizaci�n de perjuicios.</p>
                    <br>
                    <p><strong>PAR�GRAFO SEGUNDO.</strong> Se deja constancia que no se entender� incumplimiento por la
                        parte de
                        <span class=\"mark ng-binding\">EL PROMITENTE VENDEDOR</span>
                        si por fuerza mayor o caso fortuito, no puede entregar el inmueble prometido en venta en la
                        fecha
                        estipulada, por lo que el plazo de entrega se postergar� hasta el momento en que
                        <span class=\"mark ng-binding\">EL PROMITENTE COMPRADOR</span>
                        pueda superar el inconveniente que la llev� a no entregar el inmueble en la fecha establecida en
                        la
                        presente promesa de compraventa.
                    </p>
                    
                    <p></p>

                    <p><strong>CL�USULA NOVENA:</strong> Las partes acuerdan solucionar las controversias que surjan por
                        raz�n
                        de �ste contrato, exceptuando las de car�cter ejecutivo, a trav�s del tr�mite
                        conciliatorio en alguno de los centros de conciliaci�n facultados para este caso.</p>

                    <p><strong>CL�USULA D�CIMA:</strong> Las partes fijan como domicilio contractual para el
                        cumplimiento de
                        todas las obligaciones emanadas de este contrato a la ciudad de
                        <span class=\"mark ng-binding\"></span>
                        . Se deja constancia de lo anteriormente pactado por las partes en fecha
                        <span class=\"mark ng-binding\">noviembre 10, 2017</span>
                        , y se expiden dos ejemplares que se entregar�n a cada una de las partes previo
                        reconocimiento de
                        firma, huella y contenido ante notario.
                    </p>

                    <p><strong>CL�USULA D�CIMA PRIMERA � M�RITO EJECUTIVO:</strong> El presente contrato de promesa de
                        compraventa prestar� por s� mismo m�rito ejecutivo, por todas las obligaciones claras, expresas
                        y
                        exigibles, de dar o de hacer aqu� contenidas, o derivadas del mismo. Para todos los efectos, las
                        obligaciones que presten m�rito ejecutivo derivadas del presente contrato podr�an ser ejecutadas
                        por
                        medio del procedimiento ejecutivo ante la jurisdicci�n ordinaria y ante los jueces de la
                        Rep�blica de
                        Colombia, o a trav�s de un Tribunal de Arbitramento o centro de conciliaci�n competente.
                    </p>

                    <p><strong>CL�USULA D�CIMA SEGUNDA � COMPROMISORIA:</strong> Toda controversia o diferencia relativa
                        a este
                        contrato y a su ejecuci�n e interpretaci�n, se resolver� en primera instancia por el arreglo
                        directo
                        entre las partes, mediante una amigable conciliaci�n extrajudicial, transacci�n, amigable
                        composici�n o
                        cualquier otro m�todo previsto por la Ley. No obstante, si no fue posible solucionar los
                        inconvenientes
                        acaecidos, �stos se dirimir�n a decisi�n de la parte que decida iniciar el proceso, a trav�s de
                        una de
                        las siguientes v�as, (i) por un Tribunal de Arbitramento, que se sujetar� al reglamento del
                        Centro de
                        Arbitraje y Conciliaci�n de la C�mara de Comercio de
                        <span class=\"mark ng-binding\"></span>
                        , de acuerdo con las siguientes reglas:
                        <br>
                    </p><ul style=\"list-style:none;\">
                        <li>A. El Tribunal estar� integrado por un (1) �rbitro designado por mutuo acuerdo entre las
                            partes y, a
                            falta de acuerdo, por sorteo realizado por la C�mara de Comercio de
                            <span class=\"mark ng-binding\"></span>
                            de sus listas de �rbitros, sin recurrir a la Justicia Ordinaria.
                        </li>
                        <li>B. El Tribunal decidir� en derecho.</li>
                        <li>C. El Tribunal tendr� sede en
                            <span class=\"mark ng-binding\"></span>
                            o, (ii) por la justicia ordinaria colombiana, o sea, los jueces y cortes de la Rep�blica de
                            Colombia.
                        </li>
                    </ul>
                    <p></p>

                    <p><strong>CL�USULA D�CIMA TERCERA � MODIFICACIONES AL CONTRATO:</strong> Esta promesa de
                        compraventa no
                        podr� ser modificada sino por medio de documento escrito y firmado con reconocimiento notarial
                        por ambas
                        partes.
                    </p>

                    <p><strong>CL�USULA D�CIMA CUARTA � CESI�N:</strong>
                        <span class=\"mark ng-binding\">EL PROMITENTE VENDEDOR</span>
                        podr� ceder los derechos adquiridos en el presente contrato a favor de un tercero, previa
                        manifestaci�n
                        expresa y escrita dirigida a
                        <span class=\"mark ng-binding\">EL PROMITENTE COMPRADOR</span>
                        .
                        <span class=\"mark ng-binding\">EL PROMITENTE COMPRADOR</span>
                        podr� ceder la presente promesa de compraventa, previa autorizaci�n escrita de
                        <span class=\"mark ng-binding\">EL PROMITENTE VENDEDOR</span>
                        .
                    </p>

                    <p><strong>CL�USULA D�CIMA QUINTA � DOMICILIO CONTRACTUAL:</strong> Se fija como domicilio para el
                        cumplimiento judicial o extrajudicial de este contrato, la ciudad de
                        <span class=\"mark ng-binding\"></span>
                        .
                    </p>

                    <p><strong>CL�USULA D�CIMA SEXTA � RESOLUCI�N IPSO-FACTO:</strong> El presente contrato queda
                        resuelto
                        Ipso-Facto sin necesidad de declaraci�n judicial en los siguientes casos:
                        <br>
                    </p><ul style=\"list-style:none;\">
                        <li>A. Por incumplimiento de
                            <span class=\"mark ng-binding\">EL PROMITENTE VENDEDOR</span>
                            por la no entrega del inmueble.
                        </li>
                        <li>B. Por el incumplimiento de
                            <span class=\"mark ng-binding\">EL PROMITENTE COMPRADOR</span>
                            de los pagos pactados en la cl�usula relativa al precio.
                        </li>
                        <li>C. Por no firmar la Escritura o por no cumplir con cualquiera de las dem�s obligaciones que
                            se
                            establecen el presente contrato.
                        </li>
                    </ul>
                    <br>
                    <p><strong>PAR�GRAFO PRIMERO:</strong> En caso de resoluci�n del contrato debido al incumplimiento
                        de
                        <span class=\"mark ng-binding\">EL PROMITENTE COMPRADOR</span>
                        ,
                        <span class=\"mark ng-binding\">EL PROMITENTE VENDEDOR</span>
                        podr� disponer de los inmuebles prometidos en venta, previa comunicaci�n enviada a
                        <span class=\"mark ng-binding\">EL PROMITENTE COMPRADOR</span>
                        a la direcci�n registrada en este contrato, comunicaci�n que invocar� la causal de
                        incumplimiento, y
                        apropiarse de los dineros recibidos a t�tulo de cl�usula penal, es decir del 20% del valor total
                        del
                        precio de venta, como se prev� en este contrato, devolviendo el excedente si lo hubiere a
                        <span class=\"mark ng-binding\">EL PROMITENTE COMPRADOR</span>
                        sin intereses de ning�n tipo en un plazo de ciento veinte (120) d�as calendario contados a
                        partir de la
                        fecha de la notificaci�n o comunicaci�n por parte de
                        <span class=\"mark ng-binding\">EL PROMITENTE VENDEDOR</span>
                    </p>
                    <br>
                    <p><strong>PAR�GRAFO SEGUNDO:</strong> La presente promesa se encuentra sujeta a la siguiente
                        condici�n
                        resolutoria. Es claro para las partes que el presente contrato se ha celebrado en especial
                        atenci�n de
                        la calidad de persona(s) que integran o componen la parte
                        <span class=\"mark ng-binding\">EL PROMITENTE COMPRADOR</span>
                        , por lo tanto si se diere el caso de fallecimiento o disoluci�n de una o de algunas de las
                        personas que
                        la integran, el presente contrato se resolver� de pleno derecho, sin necesidad de decisi�n
                        judicial y
                        <span class=\"mark ng-binding\">EL PROMITENTE VENDEDOR</span>
                        devolver� los dineros recibidos, sin deducci�n alguna y sin causaci�n de intereses, conforme a
                        las
                        normas del C�digo Civil y C�digo General del Proceso Colombianos (adjudicatarios de los
                        derechos,
                        debidamente reconocidos por la sucesi�n), y en tal virtud
                        <span class=\"mark ng-binding\">EL PROMITENTE VENDEDOR</span>
                        queda en absoluta libertad de disponer de los inmuebles objeto del presente contrato para que
                        sea
                        comercializado y vendido nuevamente a un tercero sin requerir para ello autorizaci�n judicial.
                    </p>
                    <p></p>

                    <p><strong>CL�USULA D�CIMA S�PTIMA � ENTREGA DEL INMUEBLE:</strong>
                        <span class=\"mark ng-binding\">EL PROMITENTE VENDEDOR</span>
                        , har� entrega real y material del inmueble objeto del presente contrato a
                        <span class=\"mark ng-binding\">EL PROMITENTE COMPRADOR</span>
                        al momento de:
                        <span class=\"mark ng-binding\" ng-hide=\"answers.entregainmueble==='Defina otra (fecha o evento)'\">
                            la firma de la escritura p�blica.
                        </span>
                        <!-- ngIf: answers.entregainmueble==='Defina otra (fecha o evento)' -->
                    </p>
                    <p></p>
                    &nbsp;
                    <p><strong>CL�USULA D�CIMA OCTAVA</strong> No obstante la menci�n del �rea, cabida y linderos de la
                        presente
                        promesa de compraventa sobre el (los) inmueble(s) antes mencionados, se hace sobre cuerpo cierto
                        y
                        comprende todas las mejoras, usos y costumbres, anexidades y servidumbres que legal y
                        naturalmente le(s)
                        corresponda.
                    </p>

                    <p><strong>CL�USULA D�CIMA NOVENA � NOTIFICACIONES:</strong> Cualquier notificaci�n que deba
                        surtirse entre
                        las partes ser� legalmente v�lida cuando se dirija por correo certificado a las siguientes
                        direcciones:
                        <br><span>
                    </span></p><p>
                        <span class=\"mark ng-binding\">EL PROMITENTE VENDEDOR</span>
                    </p>
                    <p>
                        <span class=\"mark ng-binding\"><b>E-mail:</b> johan@gmail.com</span>
                        ;
                        <span class=\"mark ng-binding\"><b>Direcci�n:</b> calle 6 sur # 14-25</span>
                    </p>
                    

                    <br><span><p><span class=\"mark ng-binding\">EL PROMITENTE COMPRADOR</span></p><p><span class=\"mark ng-binding\"><b>E-mail:</b> brayan@gmail.com</span>;<span class=\"mark ng-binding\"><b>Direcci�n:</b> calle 63 # 45-78</span></p></span>
                    <p></p>
                    <p><strong>CL�USULA VIG�SIMA:</strong><br><b>Anexos:</b><br> Forman parte del presente contrato de
                        promesa
                        de compraventa los documentos que a continuaci�n se mencionan:
                    </p><ul style=\"list-style: none;\">
                        <li><b>1.</b>Certificado de libertad y tradici�n del inmueble objeto de la venta.</li>
                        <li><b>2.</b>Escrituras p�blicas de tradici�n del inmueble.</li>
                        <li><b>3.</b>Fotocopias de las c�dulas de ciudadan�a de las partes aqu� firmantes.</li>
                        <li><b>4.</b>Los otros s� que suscriban las partes con posterioridad a la firma del presente
                            documento y
                            antes de la protocolizaci�n del contrato de promesa de compraventa.
                        </li>
                        <li><b>5.</b>Paz y salvos prediales y de valorizaci�n.</li>
                        <li><b>6.</b>Copias recientes de certificados de existencia y representaci�n de c�mara de
                            comercio, si
                            intervienen personas Jur�dicas.
                        </li>
                        <li><b>7.</b>Los dem�s que tengan incidencia en el presente negocio y el de su protocolizaci�n.
                        </li>
                    </ul>

                    <p></p>
                    <!-- ngIf: answers.propiedadhorizontal==='si' || answers.propiedadhorizontal2==='si' || answers.propiedadhorizontal3==='si' || answers.propiedadhorizontal4==='si' --><p ng-if=\"answers.propiedadhorizontal==='si' || answers.propiedadhorizontal2==='si' || answers.propiedadhorizontal3==='si' || answers.propiedadhorizontal4==='si'\" class=\"ng-scope\">
                        <strong>CL�USULA VIG�SIMA PRIMERA:R�GIMEN DE PROPIEDAD HORIZONTAL.</strong> Que el inmueble
                        objeto de
                        esta compra venta fue sometido al regimen de PROPIEDAD HORIZONTAL mediante la
                        <!-- ngIf: answers.propiedadhorizontal==='si' --><span class=\"mark ng-scope\" ng-if=\"answers.propiedadhorizontal==='si'\">designado mediante la escritura p�blica
                            <span class=\"mark ng-binding\">213421341</span>
                            , con fecha
                            <span class=\"mark ng-binding\">noviembre 10, 2017</span>
                            , elevando ante la Notar�a
                            <span class=\"mark ng-binding\">121312312</span>
                            , del C�rculo de
                            <span class=\"mark ng-binding\"></span>
                        </span><!-- end ngIf: answers.propiedadhorizontal==='si' -->
                        <!-- ngIf: answers.propiedadhorizontal2==='si' -->
                        <!-- ngIf: answers.propiedadhorizontal3==='si' -->
                        <!-- ngIf: answers.propiedadhorizontal4==='si' -->
                        el cual fue debidamente inscrito en el folio de matr�cula inmobiliaria respectivo.Dicho
                        reglamento de
                        propiedad horizontal y sus subsiguientes reformas se entienden incorporadas a la presente
                        promesa.
                    </p><!-- end ngIf: answers.propiedadhorizontal==='si' || answers.propiedadhorizontal2==='si' || answers.propiedadhorizontal3==='si' || answers.propiedadhorizontal4==='si' -->
                    <br>
                    _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
                    <br>
                    <p>
                        <br>
                        <span class=\"mark ng-binding\">EL PROMITENTE VENDEDOR</span>
                        <br>
                        <br>
                        <br>
                        _______________________________________________<br>

                        <!-- ngIf: answers.tipo.vendedor=== 'natural' --><span class=\"mark ng-binding ng-scope\" ng-if=\"answers.tipo.vendedor=== 'natural'\">JOHSN</span><!-- end ngIf: answers.tipo.vendedor=== 'natural' -->
                        <!-- ngIf: answers.tipo.vendedor=== 'juridico' -->
                        <br>
                        <!-- ngIf: answers.tipo.vendedor=== 'natural' --><span class=\"mark ng-binding ng-scope\" ng-if=\"answers.tipo.vendedor=== 'natural'\">
                            435435424675
                        </span><!-- end ngIf: answers.tipo.vendedor=== 'natural' -->
                        <!-- ngIf: answers.tipo.vendedor=== 'juridico' -->
                    </p>

                    <!-- ngIf: answers.tipo.vendedor2=== 'juridico' || answers.tipo.vendedor2=== 'natural' -->

                    <!-- ngIf: answers.tipo.vendedor3=== 'juridico' || answers.tipo.vendedor3=== 'natural' -->

                    <!-- ngIf: answers.tipo.vendedor4=== 'juridico' || answers.tipo.vendedor4=== 'natural' -->

                    &nbsp;

                    <p>
                        <br>
                        <span class=\"mark ng-binding\">EL PROMITENTE COMPRADOR</span>
                        <br>
                        <br>
                        <br>
                        _______________________________________________<br>
                        <!-- ngIf: answers.tipo.comprador=== 'natural' --><span class=\"mark ng-binding ng-scope\" ng-if=\"answers.tipo.comprador=== 'natural'\">Brayan Hamer Rodriguez Sanchez</span><!-- end ngIf: answers.tipo.comprador=== 'natural' -->
                        <!-- ngIf: answers.tipo.comprador=== 'juridico' -->
                        <br>
                        <!-- ngIf: answers.tipo.comprador=== 'natural' --><span class=\"mark ng-binding ng-scope\" ng-if=\"answers.tipo.comprador=== 'natural'\">
                            
                        </span><!-- end ngIf: answers.tipo.comprador=== 'natural' -->
                        <!-- ngIf: answers.tipo.comprador=== 'juridico' -->
                    </p>

                    <!-- ngIf: answers.tipo.comprador2=== 'juridico' || answers.tipo.comprador2=== 'natural' -->

                    <!-- ngIf: answers.tipo.comprador3=== 'juridico' || answers.tipo.comprador3=== 'natural' -->

                    <!-- ngIf: answers.tipo.comprador4=== 'juridico' || answers.tipo.comprador4=== 'natural' -->
                  
                ";
// Create the object from the class
$htmltodoc= new HTML_TO_DOC();

// Pass the variable which contains the code to the object.
// The 3rd parameter forces to download the generated Microsoft Word document.

$htmltodoc->createDoc(utf8_encode($content), "my_filename.doc", true);